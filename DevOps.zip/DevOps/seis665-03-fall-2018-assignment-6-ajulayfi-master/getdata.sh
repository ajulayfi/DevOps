#!/bin/bash
touch access_log
sudo cp /var/log/httpd/access_log access_log
