# !/bin/bash
# assign variables

ACTION=${1}

function my_l()

{
   sudo cp /var/log/httpd/access_log access_log
}

function my_m()
{
touch metadata.txt
curl -w "\n" http://169.254.169.254/latest/meta-data/hostname >> metadata.txt
curl -w "\n" http://169.254.169.254/latest/meta-data/iam/info >> metadata.txt
curl -w "\n" http://169.254.169.254/latest/meta-data/security-groups > metadata.txt
}

function my_d(){
touch db.txt
nc -vz midterm-db.cjkzmxsmbrte.us-east-1.rds.amazonaws.com 3306 > db.txt
}

function my_j(){

for file in * .json

do

echo $file

cat $file

done

}
case "$ACTION" in
    -l)
my_l
;;
	-m)
	my_m
	;;

	-d)
	my_d
	;;
	-j)
	my_j
	;;
*)

echo "Usage $ACTION{0} {-l|-m|-d|-j}"

exit 1

esac

