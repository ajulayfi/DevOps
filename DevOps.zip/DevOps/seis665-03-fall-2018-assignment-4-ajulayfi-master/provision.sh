#!/bin/bash
# assign variables
ACTION=${1}
version=1.0.0
function start_webserver () { 
sudo yum update -y
sudo yum install nginx -y
sudo chkconfig nginx on 
sudo aws s3 cp s3://alju3541-assignment-4/index.html /usr/share/nginx/html/index.html
sudo service nginx start 

}
 
 
 
function remove_file () {
sudo service nginx stop
sudo rm -r /usr/share/nginx/html/*
sudo yum remove nginx -y
}
 
function show_version (){
 
echo  $version
}
 
function display_help() {
 
cat << EOF
Usage: ${0} {-v|--version|-r|--remove|-h|--help} <filename>
 
OPTIONS:
	${0} |--start webserver
        -r |--shotdwon webserver
        -v |-- the version
        -h | --help     Display the command help
 
Examples:
Show the version:
                $ ${0} -v
        shotdwon webserver:
                $ ${0} -r
        Display help:
                $ ${0} -h
	start webserver:
                $ ${0} 
EOF
}


START=${0}

case "$ACTION" in
        -h|--help)
                display_help
                ;;
        -r|--remove)
                remove_file
                ;;
        -v|--version)
                show_version
                ;;

*)
if [ "$START" = "./provision.sh" ] && [ "$ACTION" = "" ]
then 
start_webserver
else
  	echo "Usage ${0} or ${0} {-h|-r|-v}"
fi
        exit 1 
esac
