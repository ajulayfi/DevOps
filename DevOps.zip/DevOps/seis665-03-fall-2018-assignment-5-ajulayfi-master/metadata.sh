 #!/bin/bash
# assign variables
ACTION=${1}
version=0.1.0
function create_files() {

touch rds-message.txt ecoweb1-identity.json 

nc -vz ecotech-db1.cjkzmxsmbrte.us-east-1.rds.amazonaws.com 3306 > rds-message.txt
curl -w "\n" http://169.254.169.254/latest/dynamic/instance-identity/document/ > ecoweb1-identity.json

}


function show_version (){

echo "The version is $version."
}



case "$ACTION" in
           -c|--create)
                create_files
                ;;
            -v|--version)
                show_version
                ;;
        *)
	echo "Usage ${0} {-c|—-create|-v|--version}"
        exit 1
esac
